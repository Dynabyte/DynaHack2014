Start with ```python start.py``` and your endpoint will be ```http://<ip-number>:8080/make-move```

Start with ```python start.py 1337``` and your endpoint will be ```http://<ip-number>:1337/make-move```

Implement your AI in ```shipsinker.py```.
