#!/usr/bin/env python
# -*- coding: utf-8 -*-
class Coordinate:
    def __init__(self, x, y):
        self.x = x
        self.y = y