#dynaShipClient_nodejs
=====================

A client for DynaHack written in NodeJS

##Building and running
Download and install [Node.js](http://nodejs.org/)

Install the dependencies:
```
> npm install
```

Then run:
```
> npm start
```