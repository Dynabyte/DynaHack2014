module.exports = function (app) {
    'use strict';
    return {
        ai: require('./routes/ai')(app)
    };
};