(function () {
    'use strict';
    var express = require('express'),
        util = require('util'),
        app = express(),
        bodyParser = require('body-parser');

    // Setting port
    app.set('port', process.env.PORT || 1337);

    // Configure app
    app.use(bodyParser.json());

    // init routes
    require('./routeManager')(app);

    // Starting the server
    app.listen(app.get('port'), function () {
        util.log('DynaShip server listening on port ' + app.get('port') + '!');
    });
}());