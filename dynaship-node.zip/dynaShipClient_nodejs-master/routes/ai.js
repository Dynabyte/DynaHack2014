module.exports = function (app) {
    'use strict';

    var util = require('util'),

        init = function () {
            util.log('init logic goes here');
        },

        dispose = function () {
            util.log('dispose logic goes here');
        };

    app.post('/', function (req, res) {
        util.log('POSTED DATA: ' + JSON.stringify(req.body));

        var answer = {
            'x': Math.floor(Math.random() * req.body.size),
            'y': Math.floor(Math.random() * req.body.size)
        };

        //todo: do you magic here!!

        util.log('RESPONSE DATA: ' + JSON.stringify(answer));
        res.status(200).send(answer);
    });

    app.get('/', function (req, res) {
        util.log('GET: ' + req.url);
        res.status(200).send('Post your data instead!');
    });

    // run init the first time
    init();

    return {
        init: init,
        dispose: dispose
    };
};