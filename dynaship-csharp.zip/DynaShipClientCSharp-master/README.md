DynaShipClientCSharp
====================
Implement your AI in DynaShipAI.cs
