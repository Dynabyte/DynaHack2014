﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Coordinate
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
