dynaship-rest-java
==================

RESTful service api built in java using Dropwizard and Maven

INSTALLATION

Using Eclipse nad M2E plugin:
- Import project.
- Start service by right-clicking on GetMoveService.launch > Run As > GetMoveService

Using standalone Maven (command line):
- In project directory, run: ```mvn package```
- Start service by running: ```java -jar /target/dynaship-rest-java-0.0.1-SNAPSHOT.jar server config.yml```

Your endpoint is then ```http://<ip-address>:8080/dynaship/get-move```

Implement your logic in se.dynabyte.dynaship.service.getmove.ai.BasicGameStateEvaluationStrategy.java
