package se.dynabyte.dynaship.service.getmove.configuration;

import com.yammer.dropwizard.config.Configuration;

public class GetMoveConfiguration extends Configuration {
}
