package se.dynabyte.dynaship.service.getmove;

public class MediaType {

	public static final String APPLICATION_JSON_UTF_8 = "application/json; charset=utf-8";
	
}
